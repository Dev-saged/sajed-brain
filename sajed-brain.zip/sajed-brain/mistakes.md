# أخطاء حدثت — لا تكررها أبداً
_يُضاف إليه فور اكتشاف خطأ جديد_

## GitHub Actions / CI
- **العَرَض:** `gh api` يرجع "null" على ملف غير موجود في bulk workflow
  **السبب:** `gh api` يرجع "null" string وليس خطأ على 404
  **الإصلاح:** تحقق من وجود الملف أولاً `gh api repos/.../contents/path --silent` قبل أي PUT

- **العَرَض:** unpack-zip.yml يفشل أو يضع الملفات في مجلد فرعي
  **السبب:** zip محتوي على مجلد wrapper (nested folder)
  **الإصلاح:** عند رفع zip من الهاتف، flatten الـzip مباشرة بلا مجلد wrapper

## التصميم والـStack
- **العَرَض:** ألوان المشروع تتغير بناءً على wallpaper المستخدم
  **السبب:** Material You dynamic color كان default
  **الإصلاح:** Material You = opt-in فقط في BrandConfig؛ brand palette هي الافتراضي دائماً

## Room / قاعدة البيانات
- لا تعدّل migration قديمة أبداً حتى لو كان الخطأ واضحاً — أضف migration جديدة
- Balance لا يُخزَّن في قاعدة البيانات — يُحسَب دائماً من transactions

## الكود
- لا تُبسّط الكود أو تُعيد هيكلته دون طلب صريح من ساجد
- لا تحذف ميزة موجودة قبل إخبار ساجد والحصول على موافقة
- لا تُعيد توليد ملف كامل — edits محددة فقط
